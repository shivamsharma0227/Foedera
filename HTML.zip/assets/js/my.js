$(document).ready(function() {
	$('.header').next().css({"margin-top":"62px"})
	$('#hamburger').click(function() {
		$('.nav-list').toggleClass('nav-list-display');
		$(this).toggleClass('active');
		$('.navigation').slideToggle();
	});	
	$('.product-list').slick({
		arrows:true,		
		slidesToShow: 4,
		autoplay:true,
        slidesToScroll: 1,	
		responsive: [
	    {
	      breakpoint: 1024,
	      settings: {
	        slidesToShow: 3        
	      }
	    },
	    {
	      breakpoint: 600,
	      settings: {
	        slidesToShow: 2      
	      }
	    },
	    {
	      breakpoint: 480,
	      settings: {
	        slidesToShow: 1
	      }
	    }]
	});
	
	$('.symbol-links').slick({
		arrows:false,		
		slidesToShow: 7,
		autoplay:true,
        slidesToScroll: 1,	
		responsive: [
	    {
	      breakpoint: 1024,
	      settings: {
	        slidesToShow: 6        
	      }
	    },
	    {
	      breakpoint: 600,
	      settings: {
	        slidesToShow: 4      
	      }
	    },
	    {
	      breakpoint: 480,
	      settings: {
	        slidesToShow: 2
	      }
	    }]
	});
	
	$('.testimonials-list').slick({
		arrows:false,
		dots:true,
		autoplay:true				
	});
	
	
	$('.video').parent().click(function () {
    if($(this).children(".video").get(0).paused){
        $(this).children(".video").get(0).play();
        $(this).children(".playpause").fadeOut();
        $(this).children(".video").attr("controls","")
    }else{
       $(this).children(".video").get(0).pause();
        $(this).children(".playpause").fadeIn();
    }
	});
	
	$('.client-slider').slick({
		arrows:false,
		infinite:true,
		slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: true,	
		responsive: [
	    {
	      breakpoint: 1024,
	      settings: {
	        slidesToShow: 4        
	      }
	    },
	    {
	      breakpoint: 600,
	      settings: {
	        slidesToShow: 2      
	      }
	    },
	    {
	      breakpoint: 480,
	      settings: {
	        slidesToShow: 1
	      }
	    }]
	});

	$('#filters').click(function(){
		$('.search-filter-wrapper').slideToggle();	
	});
	$('#categories').click(function(){
		$('.categories-section').slideToggle();
	});	
	$('#sort-button').click(function(){
		$('.sort-menu').toggle();
	});
	
	
	$('#add-new-button').click(function(){
		$('#add-new-fields').slideToggle();
	});
	
	$('#place-add-adres').click(function(){
		$('#place-new-adres').slideToggle();
	});	
	
	$('#category-list .category-heading').click(function(){
		$(this).siblings('.category-content').slideToggle();
		$(this).parent().toggleClass('rotated-arrow');
		$(this).parent().siblings().removeClass('rotated-arrow');
		$(this).parent().siblings().children('.category-content').hide();
	});	
	
	$(window).scroll(function() {
		var sticky = $('.filter-wrapper'),
		    scroll = $(window).scrollTop();

		if (scroll >= 200){
			sticky.addClass('blue-filter-wrapper');
			$('.equipment-category-area').css('margin-top','83px')
		}
		else{
			sticky.removeClass('blue-filter-wrapper');
				$('.equipment-category-area').css('margin-top','0')
		}
	});
	
	
	//edit address js//
	$('body').click(function(){
		$('.edit-options').hide();
		$('.language-change').hide();
	});
	$('#edit-add').click(function(e){		
		$('.edit-options').toggle();
		e.stopPropagation();		
	});
	$('.edit-options').click(function(e){
		e.stopPropagation();		
	});
	//edit address js//	
	
	
	//language opener js//
	$('.language a').click(function(){
		$('.language-change').toggle();
	});
	$('.language a').click(function(e){
		e.stopPropagation();
	});
	$('.language-change').click(function(e){
		e.stopPropagation();
	});
	//language opener js//
	
	$('.account-setting').click(function(){
		$('.account-setting-sub').slideToggle();
	});
	$('.account-setting-sub').click(function(e){		      	
        e.stopPropagation();  			
	});
	
	
	//account tabing js
	
	$('.side-action li a').click(function() {
		var tabDivId = this.hash;		
		$('.account-right-smiliar').hide();
		$(tabDivId).fadeIn();
		$('.side-action li').removeClass('active');
		$(this).parent().addClass('active');				
		return false;
	});	
	$('#edit-product').click(function() {
		$('#edit-new-eqmt').fadeIn('slow');
		$(this).closest('.account-right-smiliar').fadeOut('slow');
	});
	
//*************************************popup js**************************************//	
  	
  	 
	$('.login-button').click(function(){
		$('#login-popup').parent().fadeIn('slow');		
		$('#login-popup').parent().siblings('.black-popup-overlay').hide();		
		$('body').addClass('overflow-hidden');
	});
	$('.signup-button').click(function(){
		$('#signup-popup').parent().fadeIn('slow');
		$('#signup-popup').parent().siblings('.black-popup-overlay').hide();
		$('body').addClass('overflow-hidden');
	});
	$('.forget-link').click(function(){
		$('#forget-popup').parent().fadeIn('slow');
		$('#forget-popup').parent().siblings('.black-popup-overlay').hide();
		$('body').addClass('overflow-hidden');
	});
	$('#forget-next').click(function(){
		$('#verification-popup').parent().fadeIn('slow');
		$('#verification-popup').parent().siblings('.black-popup-overlay').hide();
		$('body').addClass('overflow-hidden');
	});
	$('.black-popup-overlay').click(function(){		      	
        $(this).fadeOut('slow');  
        $('body').removeClass('overflow-hidden');  			
	});
	$('.common-popup').click(function(e){		      	
        e.stopPropagation();  			
	});
	$('.cross-popup').click(function(){
		$(this).parent().parent().fadeOut('slow');
		$('body').removeClass('overflow-hidden');
	});
	
	// edit address popup //
	$('#edit-popuop').click(function(){
		$('#edit-address-field').parent().fadeIn('slow');		
		$('body').addClass('overflow-hidden');
	});	
	$('#edit-address-field').click(function(e){		      	
        e.stopPropagation();  			
	});	
	
	$('#place-edit').click(function(){
		$('#place-edit-pop').parent().fadeIn('slow');		
		$('body').addClass('overflow-hidden');
	});	
	$('#place-edit-pop').click(function(e){		      	
        e.stopPropagation();  			
	});
	$('#place-edit-pop .cross-popup').click(function(){
		$(this).parent().parent().fadeOut('slow');
		$('body').removeClass('overflow-hidden');
	});
	// edit address popup //
	
	
	//add new card//
	$('#add-new-card').click(function(){
		$('.enter-card-wrapper').slideToggle();
	});	
	//add new card//
	
	//remove button js//
	$('#remove').click(function(){
		$('#delete-popup').parent().fadeIn('slow');
		$('body').addClass('overflow-hidden');
	});
	$('#delete-popup').click(function(e){		      	
        e.stopPropagation();  			
	});
	//remove button js//
	
	
	//guest popup js//
	$('#guest-button').click(function(){
		$('#guest-checkout').parent().fadeIn('slow');
		$('body').addClass('overflow-hidden');
	});
	$('#guest-checkout').click(function(e){		      	
        e.stopPropagation();  			
	});
		//guest functionality
		$('#next-steps').click(function(){			
			$('.guest-first-block').hide();
			$('.guest-second-block').show();
		});	
		$('#previous-steps').click(function(){			
			$('.guest-first-block').show();
			$('.guest-second-block').hide();
		});	
	//guest popup js//
	
	
	//order management//
	$('#od-mngmt-view').click(function(){
		$('#view-details').parent().fadeIn('slow');
		$('body').addClass('overflow-hidden');
	});	
	//order management//	
	
	//detail table slide//	
	$('#dtl-table').click(function(){
		$('#view-dtl-table').slideToggle();
	});	
	$('#dtl-table1').click(function(){
		$('#view-dtl-table1').slideToggle();
	});
	$('#dtl-table2').click(function(){
		$('#view-dtl-table2').slideToggle();
	});
	//detail table slide//
	
	
	$('#carousel').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: false,
    slideshow: false,
    itemWidth: 116,
    itemMargin: 8,
    asNavFor: '#slider'
  }); 
 
  // product slider //
  $('#slider').flexslider({
    animation: "slide",
    controlNav: false,
    animationLoop: false,    
    slideshow: false,
    sync: "#carousel"
  });
  
 
  
});